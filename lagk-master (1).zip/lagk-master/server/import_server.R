working.data.dir <- reactive({
  file.path("data_ts", input$data.dir)
})
#------------------------------------------------------------------------------
na.replace <- c("", " ", "Eqp", "#N/A", "-999999")
#------------------------------------------------------------------------------
hourly.df <- reactive({

  hourly.df <- file.path(working.data.dir(), "flows_obs/flow_hourly_cfs.csv") %>% 
    data.table::fread(data.table = FALSE,
                      na.strings = na.replace) %>% 
    dplyr::filter(!is.na(site)) %>% 
    #    dplyr::mutate(date_time = lubridate::mdy_hm(date_time)) %>% 
    dplyr::mutate(date_time = lubridate::ymd_hms(date_time)) %>% 
    dplyr::filter(!is.na(flow))
  
  return(hourly.df)
})
#------------------------------------------------------------------------------
daily.df <- reactive({
  daily.df <- file.path(working.data.dir(), "flows_obs/flow_daily_cfs.csv") %>% 
    data.table::fread(data.table = FALSE,
                      na.strings = na.replace) %>% 
    dplyr::filter(!is.na(site)) %>% 
    #   dplyr::mutate(date_time = as.Date(date_time, format = "%m/%d/%Y"))
    #   dplyr::mutate(date_time = as.Date(date_time, format = "%Y-%m-%d"))
    dplyr::mutate(date_time = as.POSIXct(date_time),
                  date_time = lubridate::ymd(date_time))
  
  #----------------------------------------------------------------------------
  hourly.test <- hourly.df() %>% 
    dplyr::mutate(date_time = lubridate::as_date(date_time)) %>% 
    filter(date_time > max(daily.df$date_time)) 
  
  if (nrow(hourly.test) > 0) {
    daily.df <- hourly.test %>% 
      dplyr::group_by(agency, site, date_time) %>% 
      dplyr::summarize(flow = mean(flow)) %>% 
      dplyr::bind_rows(daily.df, .)
  }
  #----------------------------------------------------------------------------
  
  
  return(daily.df)
})
#------------------------------------------------------------------------------


lowflow.hourly.df <- reactive({
  lowflow.hourly.df <- file.path(working.data.dir(), "flow_fc/lffs/lfalls_sim_hourly.csv") %>% 
    data.table::fread(data.table = FALSE,
                      na.strings = na.replace) %>% 
    #    plyr::mutate(date_time = lubridate::ymd_hm(datetime)) %>%
    #    dplyr::bind_rows(lffs.forecast()) %>%
    #    dplyr::filter(!is.na(flow))
    dplyr::select(datetime, lfalls_sim) %>% 
    dplyr::rename(date_time = datetime) %>% 
    dplyr::mutate(date_time = lubridate::ymd_hms(date_time)) %>% 
    tidyr::gather(site, flow, lfalls_sim)
  
  
  return(lowflow.hourly.df)
})

#------------------------------------------------------------------------------
lowflow.daily.df <- reactive({
  file.path(working.data.dir(), "flow_fc/lffs/lfalls_sim_daily.csv") %>% 
    data.table::fread(data.table = FALSE,
                      na.strings = na.replace)
})
#------------------------------------------------------------------------------
withdrawals.df <- reactive({
  with.df <- file.path(working.data.dir(), "withdrawals/withdrawals_wma_daily_mgd.csv") %>% 
    data.table::fread(data.table = FALSE,
                      na.strings = na.replace) %>% 
    dplyr::filter(!rowSums(is.na(.)) == ncol(.))
  
  
  pot.total <- with.df %>% 
    dplyr::filter(location == "Potomac River"#,
                  #day == "yesterday",
                  #measurement == "daily average withdrawals"
    ) %>% 
    dplyr::group_by(measurement, date_time, units) %>% 
    dplyr::summarize(value = sum(value)) %>% 
    dplyr::ungroup() %>% 
    dplyr::mutate(unique_id = "potomac_total") %>% 
    dplyr::filter(!rowSums(is.na(.)) == ncol(.))
  
  withdrawals.df <- dplyr::bind_rows(with.df, pot.total) %>% 
    dplyr::rename(site = unique_id,
                  flow = value) %>% 
    #    dplyr::mutate(date_time = as.Date(date_time, "%m/%d/%Y"))
    dplyr::mutate(date_time = as.Date(date_time, "%Y-%m-%d")) %>% 
    dplyr::filter(!stringr::str_detect(site, "usable storage|usable capacity"))
  
  return(withdrawals.df)
})
#------------------------------------------------------------------------------


