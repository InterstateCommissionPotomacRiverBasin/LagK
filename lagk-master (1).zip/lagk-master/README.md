# lagk
Our experiment in creating, calibrating, and using the lag-K method to route Potomac basin streamflows
